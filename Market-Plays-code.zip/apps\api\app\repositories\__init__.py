"""In-memory repositories (temporary)."""
