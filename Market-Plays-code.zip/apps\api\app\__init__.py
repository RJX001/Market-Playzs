"""Marketplays FastAPI application package."""
